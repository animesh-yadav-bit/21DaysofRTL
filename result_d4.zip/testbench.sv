module day4_tb ();
  logic [7:0]   a_i;
  logic [7:0]   b_i;
  logic [2:0]   op_i;
  logic [7:0]   alu_o;
  
  day4 dut(.*);
  
  initial begin
    // Standard procedural assignments
    a_i = 8'b10010110; 
    b_i = 8'b00000010; // Changed to 2 to make Shift results obvious
    
    // Test a random operation
    #2;
    op_i = $urandom_range(3'b111, 1'b000);
    #2;
    op_i = $urandom_range(3'b111, 1'b000);
    #2;
    op_i = $urandom_range(3'b111, 1'b000);
    #2;
    op_i = $urandom_range(3'b111, 1'b000);
    
    // IMPORTANT: Wait a bit so the change is visible in waveforms
    #10; 
    
    $finish();
  end
  
  initial begin
    $monitor("Time: %0t | Op: %b | A: %b | B: %b | Result: %b", 
              $time, op_i, a_i, b_i, alu_o);
  end
endmodule
