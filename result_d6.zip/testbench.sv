// Code your testbench here
// or browse Examples
module day6_tb();
  
  	logic        clk = 1'b0;
	logic        reset;
	logic        x_i ;
  	logic[3:0]   sr_o;
  day6 dut(.*);
  
  always begin #5 clk =~clk; end
  
  initial begin
    #5
    reset = 1'b1;
    @(posedge clk);
    reset = 1'b0;
    @(posedge clk);
    x_i=1'b1;
    #100
    $finish();
  end
  
  initial begin
    $monitor("sr_o = %b | x_i = %b | time = %t",sr_o,x_i,$time);
  end
endmodule