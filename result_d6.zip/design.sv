// Simple shift register
module day6(
  input     logic        clk,
  input     logic        reset,
  input     logic        x_i,      // Serial input

  output    logic[3:0]   sr_o
);

  always_ff @(posedge clk) begin
    if(reset) begin
      sr_o <= 4'b0000;
    end
    else begin
      sr_o <= sr_o[3:0]<<1|{3'b000,x_i};
    end
  end

endmodule