
module day2_tb ();

  logic      clk= 1'b0;;
  logic      reset;

  logic      d_i;

  logic      q_norst_o;
  logic      q_syncrst_o;
  logic      q_asyncrst_o;

  day2 DAY2 (.*);
  
  // Generate clk
  always begin
    #5 clk = ~clk;

  end

  // Stimulus
  initial begin
      $dumpfile("dump.vcd"); $dumpvars;
    d_i <= 1'b1;
    reset <= 1'b0;
    @(posedge clk);
#5  reset <= 1'b1;

  end
  
  initial begin
    $monitor("d = %b | no = %b | sync = %b | async = %b | time : %t \n",d_i,q_norst_o,q_syncrst_o,q_asyncrst_o,$time);
    #30 $finish;
  end
endmodule