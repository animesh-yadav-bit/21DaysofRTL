// Simple edge detector TB

module day3_tb ();

	logic    clk = 1'b0;
	logic    reset;
	logic    a_i;
	logic    rising_edge_o;
	logic    falling_edge_o;
  
  day3 dut(.*);
  always begin
  #5 clk = ~clk;

  end
  
  initial begin  
  $dumpfile("dump.vcd"); $dumpvars;
    reset = 1'b0;
    a_i = 1'b1;
    @(posedge clk)
    reset = 1'b1;
    @(posedge clk)
    reset = 1'b0;
  end
  
  initial begin
    $monitor("clk = %b|rst = %b | rise = %b | fall = %b | time = %t\n",clk,reset,rising_edge_o,falling_edge_o,$time);
    #30 $finish;

    end
endmodule
