 // An edge detector

module day3 (
  input     logic    clk,
  input     logic    reset,

  input     logic    a_i,

  output    logic    rising_edge_o,
  output    logic    falling_edge_o
);

  always_ff @(posedge clk) begin
    if (reset) rising_edge_o <= 1'b0;
	  else rising_edge_o <= a_i;
  end
  
  always_ff @(negedge clk) begin
    if(reset) falling_edge_o <= 1'b0;
    else falling_edge_o <= a_i;
  end
endmodule
