// A simple 2:1 mux

module day1 (
  input   logic [7:0]    a_i,
  input   logic [7:0]    b_i,
  input   logic          sel_i,
  output  logic [7:0]    y_o
);

  always_comb begin
    case(sel_i)
      1'b0: y_o=a_i;
      1'b1: y_o=b_i;
    endcase
  end
endmodule
