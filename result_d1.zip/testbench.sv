module day1_tb ();
  logic [7:0]    a_i;
  logic [7:0]    b_i;
  logic          sel_i;
  logic [7:0]    y_o;
  
  day1 dut(.*);
  
  assign a_i = 8'b0000001;
  assign b_i = 8'b1000001;
  
  initial begin
    $dumpfile("dump.vcd"); $dumpvars;
    sel_i=1'b1;
    #10
    sel_i=1'b0;
  end
  
  initial begin
	$monitor("%b",y_o);
    #20$finish;
  end
  

endmodule