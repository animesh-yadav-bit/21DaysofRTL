// Simple TB

module day5_tb ();
  logic        clk = 1'b0;
  logic        reset;
  logic[7:0]  cnt_o;
  
  day5 dut(.*);
  always begin
    #5 clk = ~clk;
  end
  
  initial begin
    reset = 1'b1;
    #5
    reset = 1'b0;
    #1500
    reset = 1'b1;
    $finish();
  end
  initial begin
    $monitor("out = %h | %d| time = %t",cnt_o,cnt_o,$time);
  end
endmodule

